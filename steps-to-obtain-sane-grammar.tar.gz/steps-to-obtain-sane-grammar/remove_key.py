from  print_grammar import gout
import sys, importlib
G = importlib.import_module(sys.argv[1].replace('.py',''))

key = sys.argv[2]

g1 = {}
for k in G.g0:
    if k == key: 
        continue
    g1[k] = []
    for r in G.g0[k]:
        g1[k].append(r.replace(key, ''))

gout(g1)
