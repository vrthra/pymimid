from  print_grammar import gout
import sys, importlib
import re
RE_NONTERMINAL = re.compile(r'(<[^<> ]*>)')
G = importlib.import_module(sys.argv[1].replace('.py',''))

def len_grammar(g): return sum([len(g[k]) for k in g])

newest_grammar = G.g0
import time, sys
L = len_grammar(newest_grammar)
diff = -1
while diff != 0:
    to_replace = []
    new_grammar1 = {}
    for k in newest_grammar:
        if len(newest_grammar[k]) != len(set(newest_grammar[k])):
            v = list(sorted(list(set(newest_grammar[k]))))
            new_grammar1[k] = v
        else:
            new_grammar1[k] = newest_grammar[k]

    for k in new_grammar1:
        if k == '<START>':
            continue
        v = new_grammar1[k]
        if len(v) == 1:
            to_replace.append((k, v[0]))

    #print(to_replace)

    if not to_replace:
        newest_grammar = new_grammar1
        break
    (k1,k2)  = to_replace[0]
    print("=> %s : %s" %(k1, k2), file=sys.stderr)
    new_grammar2 = {}
    for k in new_grammar1:
        if k == k1:
            assert len(new_grammar1[k]) == 1
            assert new_grammar1[k] == [k2]
            continue
        new_grammar2[k] = []
        rules = new_grammar1[k]
        lst = re.split(RE_NONTERMINAL, k2)
        if lst[0] == '': lst.pop(0)
        if len(lst) > 1:
            if len(lst) == 2 and lst[-1] in ['+', '?', '*']:
                sk2 = ''.join(lst)
            else:
                sk2 = '(%s)' % ''.join(lst)
        else:
            sk2 = lst[0]
        for r in rules:
            new_grammar2[k].append(r.replace(k1, sk2))

    nl = len_grammar(new_grammar2)
    diff = L - nl
    L = nl
    newest_grammar = new_grammar2

gout(newest_grammar)
