g0 = {
'<START>': ['<json_raw>'] ,
'<json_raw>': ['<json_number-1>', '[<json_list-0-c>', '{<json_dict-0-c>', '"<json_string>*"', 'false', 'null', 'true'] ,
'<json_number-1>': ['<json_number>+', '<json_number>+e<json_number>+'] ,
'<json_number>': ['+', '-', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'E', 'e'] ,
'<json_list-0-c>': ['<json_raw><json_list-7>*]', ']', '<json_list-7>+(,<json_raw>)+<json_list-6-c>'] ,
'<json_list-6-c>': [']', '<json_list-7>+(,<json_raw>)+]'] ,
'<json_list-7>': [',<json_raw>', '<json_raw>'] ,
'<json_dict-0-c>': ['}"<json_string>*":<json_raw>}', '"<json_string>*":<json_raw>,+"<json_string>*":<json_raw>}'] ,
'<json_string>': [' ', '!', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\<decode_escape-0-c>', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~'] ,
'<decode_escape-0-c>': ['"', '/', '\\', 'b', 'f', 'n', 'r', 't'] ,
}
