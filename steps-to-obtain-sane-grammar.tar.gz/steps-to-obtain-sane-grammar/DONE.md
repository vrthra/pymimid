```
# First remove space
python remove_key.py g0.py '<_skip-1-s>' > g1.py

# Then remove duplicate rules in the same key
python shrink.py g1.py > g2.py

# identify and make x+
python plus.py g2.py > g3.py

python shrink.py g3.py > g4.py

# Simplify rules by identifying optionals
python star_convert.py g4.py > g5.py

python shrink.py g5.py > g6.py
```

Removed <_from_json_raw-2> as it is simply an embedding.
Removed extra ()s

```
python shrink.py g7.py > g8.py

```

