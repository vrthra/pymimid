def gout(g):
    print('g0 = {')
    for k in g:
        print("'%s':" % k, g[k], ",")
    print('}')
