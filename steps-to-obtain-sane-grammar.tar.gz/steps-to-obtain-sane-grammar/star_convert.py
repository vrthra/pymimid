from  print_grammar import gout
import sys, importlib
import re
RE_NONTERMINAL = re.compile(r'(<[^<> ]*>)')
G = importlib.import_module(sys.argv[1].replace('.py',''))

# Star conversion: If you have <k>+<x><y><z> and <x><y><z>
# then replace <k>+<x><y><z> with <k>*<x><y><z> and drop <x><y><z>

new_g = {}
for k in G.g0:
    new_g[k] = []
    rules = G.g0[k]
    if len(rules) != 2:
        new_g[k] = G.g0[k]
        continue
    r1, r2 = reversed(sorted(rules, key=len, reverse=False)) # r1 is larger
    assert len(r1) >= len(r2)
    r1symbols = re.split(RE_NONTERMINAL, r1)
    if r1symbols[0] == '':
        r1symbols.pop(0)
    if len(r1symbols) < 2 or r1symbols[1][0] != '+':
        new_g[k] = G.g0[k]
        continue

    r1_1, r1_2, *rest = r1symbols
    s = (r1_2 + ''.join(rest))[1:]
    if s != r2:
        new_g[k] = G.g0[k]
        continue

    new_g[k] = [r1_1 + '*' + s]

gout(new_g)
