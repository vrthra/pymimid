from  print_grammar import gout
import sys, importlib
import re
RE_NONTERMINAL = re.compile(r'(<[^<> ]*>)')
G = importlib.import_module(sys.argv[1].replace('.py',''))


class Item:
    def __init__(self, value):
        self.value = value

    def __repr__(self):
        return "{Item: %s}" % self.value

from collections import namedtuple

Node = namedtuple("Node", ["value", "children"])

from pyparsing import Forward, Literal, Suppress, Word, ZeroOrMore, OneOrMore, printables, Group

import string
lpar, rpar = Literal('(').suppress(), Literal(')').suppress()

#token = Word(printables, excludeChars="()")
token = Word(''.join([i for i in (string.digits + string.ascii_letters + string.punctuation + ' ') if i not in {'(', ')'}]))
grammar = Forward()
atom = token | Group(lpar + grammar + rpar)

grammar <<  atom + ZeroOrMore(atom)
#"(" + ZeroOrMore(Word(printables, excludeChars="()")) + ZeroOrMore(grammar) + ZeroOrMore(Word(printables, excludeChars="()")) + ")"

#def parseAction(string, location, tokens):
#    return Node(value=tokens[0], children=tokens[1:])

#grammar.setParseAction(parseAction)

#r1symbols = re.split(RE_NONTERMINAL, r1)
from pyparsing import nestedExpr

def pprint(node, tab="|-"):
    print(tab + str(node.value))
    for child in node.children:
        pprint(child, tab + "    ")

tokenExpr = nestedExpr(opener='<', closer='>')
body = nestedExpr(ignoreExpr=tokenExpr)
for k in G.g0:
    for r in G.g0[k]:
        print(repr(r))
        if r.strip() in{ '', '(', ')' }:
            continue
        node = grammar.parseString(r)
        if node:
            print('\t',node)
            print()
