from  print_grammar import gout
import sys, importlib
G = importlib.import_module(sys.argv[1].replace('.py', ''))
# gets g0

# Mark + if the template is
# <k0>: <k1>, <k1><k0>
g1 = {}
for k in G.g0:
    if len(G.g0[k]) != 2:
        g1[k] = G.g0[k]
        continue
    fst, rest = G.g0[k]
    if not rest == fst + k:
        g1[k] = G.g0[k]
        continue
    g1[k] = [fst+'+']

gout(g1)
